### 阿里文档与项目文档差异

项目文档中，请求参数缺少InstanceChargeType、PricingCycle，Period，AutoPay；

项目文档中，返回参数缺少OrderId；

### lapis建议

请求参数PricingCycle使用integer类型，可以更好地描述取值范围