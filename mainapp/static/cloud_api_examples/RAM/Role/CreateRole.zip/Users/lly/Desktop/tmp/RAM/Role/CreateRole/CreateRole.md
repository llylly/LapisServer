### 项目文档与阿里文档差异

请求参数AssumeRolePolicyDocument在阿里文档中有样例说明，而项目文档中无样例说明