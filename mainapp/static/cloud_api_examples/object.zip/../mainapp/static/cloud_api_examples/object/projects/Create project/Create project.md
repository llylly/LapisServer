### 文档差别

请求体参数，项目文档少了latest_image参数

### lapis 建议

environment类型为map，其中的key-value没有明确说明，建议将类型由map改为array，每一项为一个key-value对