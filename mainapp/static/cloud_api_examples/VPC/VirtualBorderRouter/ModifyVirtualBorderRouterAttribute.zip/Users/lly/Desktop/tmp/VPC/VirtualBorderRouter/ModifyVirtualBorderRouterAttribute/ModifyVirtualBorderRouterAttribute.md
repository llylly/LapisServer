### 阿里文档与项目文档差别

请求参数VBRName、VBRDescription的名称和阿里文档有差异
