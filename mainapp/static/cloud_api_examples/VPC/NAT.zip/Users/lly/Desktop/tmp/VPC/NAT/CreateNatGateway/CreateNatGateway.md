### 项目文档与阿里文档的差异

项目文档中，API描述部分和阿里文档有差异；

项目文档中，请求参数BandwidthPackage.n.IpCount、BandwidthPackage.n.Bandwidth的、BandwidthPackage.n.Zone“是否必须”和“描述”两栏的内容与阿里文档有差异；
