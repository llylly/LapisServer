### 阿里文档与项目文档差异

项目文档中，API描述部分有差异；

项目文档中，请求参数InstanceType、InstanceId的语义描述与阿里文档有差异；

