### lapis建议

建议请求参数Bandwidth的类型为integer，以更好地描述取值范围