### 文档差别

1）ecs_image_id 列表，项目文档表中额外多了地域；
2）请求体参数，项目文档少了io_optimized参数；