### 阿里文档与项目文档差别

错误码表中差异见下表，其他部分一致

|阿里文档|项目文档|
|:-:|:-:|
|InvalidImageOwnerAlias.ValueNotSupported|InvalidImageOwnerAlias.ValueNotSupported|
|InvalidUsage|InvalidUsage|
|InvalidTag.Mismatch||
|InvalidTagCount||
|InvalidInstanceType.ValueNotSupported||
|InvalidOSType||
|InvalidArchitecture||
||MissingParameter|
||InvalidParameter|
||InvalidParameter|
