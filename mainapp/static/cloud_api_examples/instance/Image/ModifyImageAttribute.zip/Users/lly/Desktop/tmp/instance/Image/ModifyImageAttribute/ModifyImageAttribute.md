### 阿里文档与项目文档差别

错误码表中差异见下表，其他部分一致

|阿里文档|项目文档|
|:-:|:-:|
|InvalidImageName.Malformed|InvalidImageName.Malformed|
|MissingParameter|MissingParameter|
|InvalidRegionId.NotFound||
|InvalidImageName.Duplicated|InvalidImageName.Duplicated|
|InvalidDescription.Malformed|InvalidDescription.Malformed|
|InvalidImageId.NotFound|InvalidImageId.NotFound|
||MissingParameter|
