### 阿里文档勘误

API名应当为DescribeAutoSnapshotPolicyEx，而在阿里网站API概览中，显示为DescribeAutoSnapshotPolicy

### 项目文档勘误

API名应当为DescribeAutoSnapshotPolicyEx，而在项目文档API概览中，显示为DescribeAutoSnapshotPolicy

