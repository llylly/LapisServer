## CreateRole

### 项目文档与阿里文档差异

请求参数AssumeRolePolicyDocument在阿里文档中有样例说明，而项目文档中无样例说明

## GetPolicyVersion

### 项目文档与阿里文档勘误

返回参数PolicyVersion类型应为PolicyVersion Type，依据为其他同类API以及本API的返回示例

## ListPoliciesForRole

### 阿里文档与项目文档的差异

项目文档中，返回参数Roles类型和阿里文档不一致
