错误代码
MissingParameter
MissingParameter
InvalidInstanceId.No tFound
InvalidDiskId.NotFou nd
InvalidDevice.Malformed
InvalidParameter
InstanceDiskLimitExc eeded
InvalidDevice.InUse
IncorrectDiskStatus
DiskNotPortable
InstanceLockedForS ecurity
ResourcesNotInSam eZone
InstanceExpiredOrIn Arrears
DiskInArrears
IncorrectInstanceSta tus
DiskError
