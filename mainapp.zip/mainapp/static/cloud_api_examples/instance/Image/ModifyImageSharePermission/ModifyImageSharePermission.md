### 阿里文档与项目文档差别

API描述部分有差异

错误码表中差异见下表，其他部分一致

|阿里文档|项目文档|
|:-:|:-:|
|IncorrectImageStatus|IncorrectImageStatus|
|InvalidRegionId.NotFound|InvalidRegionId.NotFound|
|MissingParameter|MissingParameter|
|MissingParameter|MissingParameter|
|OperationDeined.EncryptedSnapshot||
|InvalidImageId.NotFound|InvalidImageId.NotFound|
|QuotaExceed.ShareImageUser|QuotaExceed.ShareImageUser|
|InvalidAccount.Forbbiden|InvalidAccount.Forbbiden|
|InvalidAccount.NotFound|InvalidAccount.NotFound|
||QuotaExceed.ShareImage|
