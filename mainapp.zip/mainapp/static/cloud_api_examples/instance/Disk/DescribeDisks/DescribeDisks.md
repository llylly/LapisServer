### 阿里文档与项目文档差别

项目文档中，请求参数缺少Encrypted

错误码表中差异见下表，其他部分一致

|阿里文档|项目文档|
|:-:|:-:|
|InvalidDiskType.ValueNotSupported|InvalidDiskType.ValueNotSupported|
|InvalidCategory.ValueNotSupported|InvalidCategory.ValueNotSupported|
|InvalidStatus.ValueNotSupported|InvalidStatus.ValueNotSupported|
|InvalidDiskIds.Malformed|InvalidDiskIds.Malformed|
|InvalidDiskChargeType.NotFound|InvalidDiskChargeType.NotFound|
|InvalidLockReason.NotFound||
|InvalidTag.Mismatch||
|InvalidTagCount||
|InvalidRegion.NotFound||
|InvalidZoneId.NotFound||
||MissingParameter|
||InvalidParameter|
||InvalidParameter|
||InvalidParameter|
||InvalidParameter|
||InvalidParameter|
