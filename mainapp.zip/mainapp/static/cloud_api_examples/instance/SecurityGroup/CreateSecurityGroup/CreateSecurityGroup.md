### 阿里文档与项目文档差别

错误码表中差异见下表，其他部分一致

|阿里文档|项目文档|
|:-:|:-:|
|InvalidRegionId.NotFound|InvalidRegionId.NotFound|
|InvalidSecurityGroupName.Malformed|InvalidSecurityGroupName.Malformed|
|InvalidDescription.Malformed|InvalidDescription.Malformed|
|QuotaExceed.SecurityGroup|QuotaExceed.SecurityGroup|
|InvalidVpcId.NotFound|InvalidVpcId.NotFound|
|InvalidSecurityGroupDiscription.Malformed||
|InvalidVpcId.NotFound||
|IncorrectVpcStatus||
||MissingParameter|
